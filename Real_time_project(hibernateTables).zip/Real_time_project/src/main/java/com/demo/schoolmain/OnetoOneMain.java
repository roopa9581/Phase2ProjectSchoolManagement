package com.demo.schoolmain;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.demo.model.Subjects;
import com.demo.model.Teachers;

public class OnetoOneMain {

	public static void main(String[] args) {
		Configuration configuration = new Configuration().configure();
		StandardServiceRegistryBuilder builder= new StandardServiceRegistryBuilder()
			
				.applySettings(configuration.getProperties());
		SessionFactory factory=configuration.buildSessionFactory(builder.build());
		Session session=factory.openSession();
		Transaction transaction=session.beginTransaction();
		
		Subjects s1= new Subjects("Botony");
		Subjects s2= new Subjects("Physics");
		Subjects s3= new Subjects("Zoology");
		
		Teachers t1= new Teachers("Manikanta", s1);
		Teachers t2= new Teachers("Mango", s2);
		Teachers t3= new Teachers("Mamidi", s3);


		session.save(s1);
		session.save(s2);
		session.save(s3);		
		session.save(t1);
		session.save(t2);
		session.save(t3);
	
		
		transaction.commit();
		session.close();
		factory.close();
	}
}
