package com.demo.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table
public class Teachers {

	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private int id;
	private String name;
	@OneToOne(fetch = FetchType.LAZY)
	private Subjects subjects;
	
	public Teachers() {
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Subjects getSubjects() {
		return subjects;
	}

	public void setSubjects(Subjects subjects) {
		this.subjects = subjects;
	}

	public Teachers(String name, Subjects subjects) {
		super();
		this.name = name;
		this.subjects = subjects;
	}

	@Override
	public String toString() {
		return "Teachers [id=" + id + ", name=" + name + ", subjects=" + subjects + "]";
	}

	
}